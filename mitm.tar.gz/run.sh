#!/bin/sh
SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/mitm" -importPath mitm -srcPath "$SCRIPTPATH/src" -runMode prod
