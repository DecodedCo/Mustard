// GENERATED CODE - DO NOT EDIT
package routes

import "github.com/revel/revel"


type tApp struct {}
var App tApp


func (_ tApp) FlipImages(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.FlipImages", args).Url
}

func (_ tApp) ReplaceImages(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.ReplaceImages", args).Url
}

func (_ tApp) InjectScript(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.InjectScript", args).Url
}

func (_ tApp) PassThrough(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.PassThrough", args).Url
}

func (_ tApp) RedirectPage(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.RedirectPage", args).Url
}

func (_ tApp) BlockWebsites(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.BlockWebsites", args).Url
}

func (_ tApp) GetKeylogs(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.GetKeylogs", args).Url
}

func (_ tApp) AppendData(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.AppendData", args).Url
}

func (_ tApp) GetLocations(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.GetLocations", args).Url
}

func (_ tApp) CatchLocation(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.CatchLocation", args).Url
}

func (_ tApp) InterceptHTTPS(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.InterceptHTTPS", args).Url
}

func (_ tApp) GetHars(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.GetHars", args).Url
}

func (_ tApp) DeleteHars(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.DeleteHars", args).Url
}

func (_ tApp) Login(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.Login", args).Url
}

func (_ tApp) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.Index", args).Url
}


type tStatic struct {}
var Static tStatic


func (_ tStatic) Serve(
		prefix string,
		filepath string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "prefix", prefix)
	revel.Unbind(args, "filepath", filepath)
	return revel.MainRouter.Reverse("Static.Serve", args).Url
}

func (_ tStatic) ServeModule(
		moduleName string,
		prefix string,
		filepath string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "moduleName", moduleName)
	revel.Unbind(args, "prefix", prefix)
	revel.Unbind(args, "filepath", filepath)
	return revel.MainRouter.Reverse("Static.ServeModule", args).Url
}


