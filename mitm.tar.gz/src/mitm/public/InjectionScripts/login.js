//this should pop up a window telling the user that they need to login to facebook/gmail to view this content
//"for security reasons..."
$(document).ready(function() {
	//delay for 1 second after page loads
	alert("Please login to gmail")
})